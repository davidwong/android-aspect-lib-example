/** Automatically generated file. DO NOT MODIFY */
package au.com.dw.android.aspect;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}